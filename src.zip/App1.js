import React from 'react'
import logo from './logo.svg';
import './App.css';
import './css/mystyle.css'
import my from './images/torikelly.png'

export default class App extends React.Component{
  handleDelete = () => {
    alert('삭제 하시겠어요?');
  }

  handleCreate(){
    console.log('handleCreate 함수');
    alert('신규등록을 하시겠어요?');
  }

  render(){
    //javascript 기술하는 영역
    //상수,함수,전역변수
    
    return(
      <div>
        <h1>my first React</h1>
        <img src={my} alt='토리켈리' width='200'/><br></br>
        <button onClick={this.handleCreate}>create</button>
        <button onClick={this.handleDelete}>delete</button>
        <button class='button big'>숫자증가</button>
        <button class='button small'>숫자감소</button>
      </div>
    )//return end
  }//render end
}//class end