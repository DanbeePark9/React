import React from 'react'
import logo from './logo.svg'
import './App.css'
import './css/mystyle.css'
import my from './images/torikelly.png'
import MyName from './MyName'
import Counter from './Counter'

export default class App extends React.Component{
  render(){
    //javascript 기술하는 영역
    //상수,함수,전역변수
    
    return(
      <div>
        <img src={my} alt='토리켈리' width='200'/><br></br>
        <MyName first='tori' last='kelly'></MyName>
        <Counter></Counter>
      </div>
    )//return end
  }//render end
}//class end