const MyName = ({first,last}) => {
    return(
        <span>
            닉네임: {first} {last}
        </span>
    )
}
export default MyName;