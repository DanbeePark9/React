function MyName({first,last}){
    return(
        <span>
            이름: {first} {last}
        </span>
    )
}
export default MyName;