import React from 'react'
import logo from './logo.svg'
import './App.css'
import './css/mystyle.css'
import my from './images/torikelly.png'
import MyName from './MyName'

class Counter extends React.Component{
    handleIncrease = () => {

    }//end

    handleDecrease = () => {

    }//end

    render(){
        return(
            <div>
                <h2>Counter.js</h2>
            </div>
        );
    }
}

export default Counter;