import React, {Component} from 'react';
import img1 from '../images/bts.png';
import img2 from '../images/blackpink.png';
import img3 from '../images/wanaone.png';

class MyDol extends Component{
    state={
        idols:['BTS','BlackPink','Wananone'],
        images:[
            'images/bts.png',
            'images/blackpink.png',
            'images/wanaone.png'
        ]
    }
    render(){
        //1. 고전적인 for루프 이용
        let arr=this.state.idols; 
        let str=[];
          for(let i=0;i<arr.length;i++){
            //str.push(<h3 style={{color:'blue'}} key={i}>{arr[i]}</h3>);
            str.push(<b key={i} style={{color:'blue'}} > {arr[i]} &nbsp;</b>);
          }
         
        
        //2. map()이용해보기   
        //idols:[ 'BTS','BlackPink','Wananone'],
        //images:[ 'images/bts.png', 'images/blackpink.png',
        let strImg = this.state.images.map((item, i)=>{
            return <img key={i} src={item}  width='300' height='300'></img>
        })
        
        return(
            <div>
                내가 좋아하는 아이돌 <p></p>
                {str} <p></p>
                {strImg}
            </div>
        )
    }
}
export default MyDol ;