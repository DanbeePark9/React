import React from 'react';

export default class MyChild extends React.Component{
    render(){
        return (
            <div>
                MyChild컴포넌트  {this.props.note} <br></br>
            </div>
        )
    }
}