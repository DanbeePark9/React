import React,{Component} from 'react';

export default class MyComp extends Component{
    constructor(props){
        super(props);
        //state는 반드시 초기값을 할당해야 한다.
        this.state={
            msg:'bts 반가워요',
            count:0
        }
    }

    render(){
        return (
            <div>
                <br></br>
                MyComp=ex03.js <br></br>
                <font size='5'> {this.state.msg} </font>
                <button onClick={()=>{
                    //this.state.msg="잘가셔요~~~" [x]
                    //state를 변경할때 setState()메소드이용
                    this.setState({msg:'bts 잘가셔요~~'});
                }}> <b>메세지변경버튼</b> </button>
                <hr></hr>
                
                <div style={  {width:'250px', 
                height:'100px', 
                backgroundColor:'blue',
                color:'yellow',
                fontSize:'4em',
                fontStyle:'bold',
                borderRadius:'50%',
                } }> {this.state.count} </div> 

                <button onClick={()=>{
                    this.setState({count:this.state.count+1});
                }}> <b> Count 1씩 증가</b> </button> &nbsp;

                <button onClick={function(){
                    let val=Math.floor(Math.random()*5+1);
                    this.setState({                        
                        count:this.state.count-val
                    })
                }.bind(this)}> <b>Count 랜덤하게 감소</b> </button>
            </div>
        )
    }

}