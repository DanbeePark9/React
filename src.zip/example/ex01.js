import React,{Component} from 'react';

class MyComponent extends Component{
    render(){
        let mystyle={
           color:'red',
           fontSize: '20pt',
           backgroundColor:'yellow',
           padding:'9px',
           margin:'9px' 
        }
        return (
            <div style={{padding: '10px',border: 'thick dashed blue', margin:'10px',
                        backgroundColor:'hotpink' }}>
                <h2>파일명:ex01.js   클래스명:MyComponent</h2>
                <button style={mystyle}>OK</button>
            </div>
        );
    }
}
export default MyComponent;
