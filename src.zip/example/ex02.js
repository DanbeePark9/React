import React from 'react';
import MyChild from './ex02_1';

class MyParent extends React.Component{
    render(){
        let cts=["따스한 spring","무더운 sumer","동장군 winter"];

        return (
            <div>
                <br></br>
                MyParent = ex02.js문서<br></br>
                {this.props.subtitle} {this.props.color}
                <h2 style={{color:this.props.color}}> 내용:{this.props.subtitle} </h2>
                <MyChild note={cts[0]}></MyChild>
                <MyChild note={cts[1]}></MyChild>
                <MyChild note={cts[2]}></MyChild>
            </div>
        )
    }
}

export default MyParent;