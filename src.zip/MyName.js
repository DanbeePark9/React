import React from "react"

class MyName extends React.Component {
    static defaultProps = {
        first:'one',
        last:'LA',
    }//end

    render(){
        return(
            <span>
                닉네임 : {this.props.first} {this.props.last}
            </span>
        );
    }
}

export default MyName;